#!/usr/bin/env bash
set -euo pipefail
exec npm run dev
